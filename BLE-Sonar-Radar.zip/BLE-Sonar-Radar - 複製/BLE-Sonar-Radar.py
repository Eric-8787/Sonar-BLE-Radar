import asyncio
import math
import threading
import time
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import messagebox

try:
    from bleak import BleakScanner
except ImportError:
    BleakScanner = None

try:
    import winsound
except ImportError:
    winsound = None

APP_DIR = Path(__file__).resolve().parent
SOUND_FILE = APP_DIR / "sonar_ping.wav"

DEVICE_TTL_SECONDS = 12
TRAIL_STEPS  = 18
TRAIL_SPREAD = 45

COL_BG       = "#050805"
COL_GRID     = "#115f1b"
COL_GRID_DIM = "#0e4615"
COL_SWEEP    = "#7cff8b"
COL_HIT      = "#7cff8b"
COL_FADE     = "#2fac44"
COL_TEXT     = "#e9ffe9"
COL_LABEL    = "#7cff8b"
COL_DIM_RING = "#1a7a26"

RINGS = [
    (0.25, "~2m"),
    (0.50, "~5m"),
    (0.75, "~10m"),
    (1.00, "~20m"),
]

devices         = {}
devices_lock    = threading.Lock()
scanner_error   = None
scan_start_time = time.monotonic()
peak_devices    = 0

def start_sound():
    if winsound is None or not SOUND_FILE.exists():
        return
    winsound.PlaySound(
        str(SOUND_FILE),
        winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_LOOP,
    )

def stop_sound():
    if winsound is not None:
        winsound.PlaySound(None, winsound.SND_PURGE)

def device_label(device):
    name = getattr(device, "name", None)
    address = getattr(device, "address", "unknown")
    return name or address[:8]

def get_device_type(device, adv_data):
    """
    Determine Bluetooth device brand and type ("Brand|Type").
    Priority: Manufacturer ID -> Appearance -> Device Name.
    """
    raw_name = (
        getattr(device, "name", None)
        or getattr(adv_data, "local_name", None)
        or ""
    )
    name = raw_name.lower()

    manuf = getattr(adv_data, "manufacturer_data", {}) or {}

    # Apple (0x004C = 76)
    if 76 in manuf:
        payload = manuf[76]
        m_type  = payload[0] if payload else None

        if name:
            for model in ["iphone 16 pro max", "iphone 16 pro", "iphone 16 plus", "iphone 16",
                           "iphone 15 pro max", "iphone 15 pro", "iphone 15 plus", "iphone 15",
                           "iphone 14 pro max", "iphone 14 pro", "iphone 14 plus", "iphone 14",
                           "iphone 13 pro max", "iphone 13 pro", "iphone 13 mini", "iphone 13",
                           "iphone se"]:
                if model in name:
                    return f"Apple|{model.title()}"
            if "iphone" in name: return "Apple|iPhone"
            if "ipad pro"   in name: return "Apple|iPad Pro"
            if "ipad air"   in name: return "Apple|iPad Air"
            if "ipad mini"  in name: return "Apple|iPad Mini"
            if "ipad"       in name: return "Apple|iPad"
            if "macbook pro" in name: return "Apple|MacBook Pro"
            if "macbook air" in name: return "Apple|MacBook Air"
            if "macbook"     in name: return "Apple|MacBook"
            if "mac mini"    in name: return "Apple|Mac Mini"
            if "mac studio"  in name: return "Apple|Mac Studio"
            if "mac pro"     in name: return "Apple|Mac Pro"
            if "imac"        in name: return "Apple|iMac"
            if "apple watch ultra" in name: return "Apple|Watch Ultra"
            if "apple watch se"    in name: return "Apple|Watch SE"
            if "apple watch"       in name: return "Apple|Watch"
            if "watch"             in name: return "Apple|Watch"

        # 0x07 Proximity Pairing (AirPods/Beats)
        if m_type == 0x07 and len(payload) >= 4:
            model_id = (payload[2] << 8) | payload[3]
            airpods_models = {
                0x2002: "AirPods 1st",
                0x200F: "AirPods 2nd",
                0x2013: "AirPods 3rd",
                0x200E: "AirPods Pro",
                0x2014: "AirPods Pro 2nd",
                0x2024: "AirPods Max",
                0x2003: "Powerbeats Pro",
                0x200A: "Powerbeats3",
                0x200B: "Beats X",
                0x200C: "Beats Solo3",
                0x200D: "Beats Studio3",
                0x2010: "Beats Flex",
                0x2011: "Beats Solo Pro",
            }
            label = airpods_models.get(model_id, "AirPods")
            return f"Apple|{label}"

        # 0x12 FindMy (AirTag/Accessories)
        if m_type == 0x12:
            if len(payload) >= 3:
                acc_type = payload[2]
                if acc_type == 0x00: return "Apple|AirTag"
                if acc_type == 0x01: return "Apple|FindMy Item"
            return "Apple|AirTag"

        # 0x0F Nearby Info
        if m_type == 0x0F and len(payload) >= 3:
            status = payload[2]
            os_flag = (status >> 4) & 0x0F
            if os_flag in (0x1, 0x2, 0x3):    return "Apple|iPhone"
            if os_flag in (0x4, 0x5):         return "Apple|iPad"
            if os_flag in (0x6, 0x7, 0x8):    return "Apple|Mac"
            return "Apple|iPhone"

        if m_type in (0x0E, 0x10): return "Apple|iPhone"
        if m_type == 0x0C: return "Apple|Device"
        if m_type == 0x09: return "Apple|AirPlay"
        if m_type == 0x05: return "Apple|AirDrop"

        return "Apple|Device"

    # Microsoft (0x0006 = 6)
    if 6 in manuf:
        if "surface" in name: return "Microsoft|Surface"
        if "xbox"    in name: return "Microsoft|Xbox"
        return "Microsoft|Windows"

    # Samsung (0x0075 = 117)
    if 117 in manuf:
        if any(k in name for k in ["galaxy watch", "gear"]): return "Samsung|Watch"
        if any(k in name for k in ["galaxy buds", "buds"]) : return "Samsung|Buds"
        if "galaxy" in name: return "Samsung|Galaxy"
        return "Samsung|Device"

    # Sony (0x012D = 301)
    if 301 in manuf:
        if any(k in name for k in ["wh-", "wf-", "linkbuds"]): return "Sony|Headphones"
        if "xperia" in name: return "Sony|Xperia"
        return "Sony|Device"

    # Google (0x00E0 = 224)
    if 224 in manuf:
        if "pixel"  in name: return "Google|Pixel"
        if "nest"   in name: return "Google|Nest"
        return "Google|Device"

    # Xiaomi / Redmi / POCO
    if 343 in manuf or 911 in manuf:
        if any(k in name for k in ["redmi", "poco"]):
            return f"Xiaomi|{raw_name}" if raw_name else "Xiaomi|Redmi"
        if "mi band" in name or "mi smart" in name: return "Xiaomi|Mi Band"
        if "buds"    in name: return "Xiaomi|Buds"
        return "Xiaomi|Device"

    # Huawei (0x02F4 = 756)
    if 756 in manuf:
        if "watch"   in name: return "Huawei|Watch"
        if "freebuds"in name: return "Huawei|FreeBuds"
        if "matebook"in name: return "Huawei|MateBook"
        return "Huawei|Device"

    # OPPO / OnePlus
    if 1441 in manuf:
        if "oneplus" in name: return "OnePlus|Device"
        if "enco"    in name: return "OPPO|Enco"
        return "OPPO|Device"

    # Vivo
    if 1521 in manuf:
        return "Vivo|Device"

    # Fallback: Appearance decoding
    appearance = (
        getattr(adv_data, "appearance", None)
        or getattr(device, "appearance", None)
    )
    if appearance is not None:
        cat = appearance >> 6
        sub = appearance & 0x3F
        if cat == 0x01: return "Generic|Phone"
        if cat == 0x02: return "Generic|Computer"
        if cat == 0x03:
            if sub == 1: return "Generic|Watch"
            if sub == 2: return "Generic|SportsWatch"
            return "Generic|Watch"
        if cat == 0x08: return "Generic|Audio"
        if cat == 0x0A: return "Generic|Audio"
        if cat == 0x0F: return "Generic|KB/Mouse"
        if cat == 0x1F: return "Generic|Wearable"
        if cat == 0x31: return "Generic|Tracker"

    if not name:
        return "Unknown|Device"

    # Fallback: Name keyword matching
    if "iphone"  in name: return "Apple|iPhone"
    if "ipad"    in name: return "Apple|iPad"
    if "macbook" in name: return "Apple|MacBook"
    if "airpod"  in name: return "Apple|AirPods"
    if "airtag"  in name: return "Apple|AirTag"
    if "apple"   in name: return "Apple|Device"

    if "pixel"          in name: return "Google|Pixel"
    if any(k in name for k in ["redmi", "poco"]): return f"Xiaomi|{raw_name}"
    if "xiaomi"         in name: return "Xiaomi|Device"
    if any(k in name for k in ["galaxy", "samsung"]): return "Samsung|Galaxy"
    if "huawei"         in name: return "Huawei|Device"
    if "oneplus"        in name: return "OnePlus|Device"
    if any(k in name for k in ["oppo", "reno", "find x"]): return "OPPO|Device"
    if "vivo"           in name: return "Vivo|Device"
    if any(k in name for k in ["realme", "narzo"]): return "Realme|Device"
    if "honor"          in name: return "Honor|Device"
    if "sony"           in name: return "Sony|Device"
    if "xperia"         in name: return "Sony|Xperia"

    if any(k in name for k in ["rog phone", "rog ally"]):
        return f"ASUS|{raw_name}" if raw_name else "ASUS|ROG"
    if any(k in name for k in ["rog ", "rog_", "republic of gamers"]): return "ASUS|ROG"
    if any(k in name for k in ["tuf gaming", "tuf-", "tuf_"]): return "ASUS|TUF"
    if any(k in name for k in ["zenbook", "zen book"]): return "ASUS|ZenBook"
    if any(k in name for k in ["vivobook", "vivo book"]): return "ASUS|VivoBook"
    if any(k in name for k in ["proart", "pro art"]): return "ASUS|ProArt"
    if any(k in name for k in ["expertbook", "expert book"]): return "ASUS|ExpertBook"
    if any(k in name for k in ["asus", "asustek"]): return "ASUS|Device"

    if any(k in name for k in ["thinkpad x", "thinkpad t", "thinkpad e", "thinkpad l", "thinkpad p"]):
        for series in ["x1", "x13", "x14", "t14", "t16", "e14", "e15", "l14", "l15", "p14", "p16"]:
            if series in name:
                return f"Lenovo|ThinkPad {series.upper()}"
        return "Lenovo|ThinkPad"
    if "thinkbook" in name: return "Lenovo|ThinkBook"
    if "ideapad"   in name: return "Lenovo|IdeaPad"
    if "yoga"      in name: return "Lenovo|Yoga"
    if "legion"    in name: return "Lenovo|Legion"
    if "loq"       in name: return "Lenovo|LOQ"
    if "lenovo"    in name: return "Lenovo|Device"

    if "xps"           in name: return "Dell|XPS"
    if "alienware"     in name: return "Dell|Alienware"
    if "inspiron"      in name: return "Dell|Inspiron"
    if "latitude"      in name: return "Dell|Latitude"
    if "precision"     in name: return "Dell|Precision"
    if "vostro"        in name: return "Dell|Vostro"
    if "g15"           in name: return "Dell|G15"
    if "dell"          in name: return "Dell|Device"

    if "spectre"       in name: return "HP|Spectre"
    if "envy"          in name: return "HP|Envy"
    if "omen"          in name: return "HP|Omen"
    if "pavilion"      in name: return "HP|Pavilion"
    if "elitebook"     in name: return "HP|EliteBook"
    if "probook"       in name: return "HP|ProBook"
    if "zbook"         in name: return "HP|ZBook"
    if "victus"        in name: return "HP|Victus"
    if any(k in name for k in ["hp ", "hp_"]): return "HP|Device"

    if "predator"      in name: return "Acer|Predator"
    if "nitro"         in name: return "Acer|Nitro"
    if "swift"         in name: return "Acer|Swift"
    if "aspire"        in name: return "Acer|Aspire"
    if "spin"          in name: return "Acer|Spin"
    if "chromebook"    in name: return "Acer|Chromebook"
    if "acer"          in name: return "Acer|Device"

    if any(k in name for k in ["msi ge", "msi gt", "msi gs", "msi gf", "msi gp"]): return "MSI|Gaming"
    if "raider"        in name: return "MSI|Raider"
    if "stealth"       in name: return "MSI|Stealth"
    if "katana"        in name: return "MSI|Katana"
    if "pulse"         in name: return "MSI|Pulse"
    if "creator"       in name: return "MSI|Creator"
    if "prestige"      in name: return "MSI|Prestige"
    if any(k in name for k in ["msi ", "msi_"]): return "MSI|Device"

    if "razer blade"   in name: return "Razer|Blade"
    if "razer"         in name: return "Razer|Device"
    if "galaxy book"   in name: return "Samsung|Galaxy Book"
    if "matebook"      in name: return "Huawei|MateBook"

    if "surface pro"   in name: return "Microsoft|Surface Pro"
    if "surface laptop"in name: return "Microsoft|Surface Laptop"
    if "surface book"  in name: return "Microsoft|Surface Book"
    if "surface go"    in name: return "Microsoft|Surface Go"
    if "surface"       in name: return "Microsoft|Surface"

    if any(k in name for k in ["desktop", "pc-", "-pc", "_pc"]): return "Generic|Desktop"
    if "laptop"        in name: return "Generic|Laptop"

    if any(k in name for k in ["airpod", "earpod"])  : return "Apple|AirPods"
    if any(k in name for k in ["wh-", "wf-", "linkbuds"]): return "Sony|Headphones"
    if any(k in name for k in ["buds", "earbuds"])   : return "Generic|Earbuds"
    if any(k in name for k in ["headphone", "headset"]): return "Generic|Headphones"
    if any(k in name for k in ["speaker", "soundbar"]): return "Generic|Speaker"
    if any(k in name for k in ["jbl", "bose", "beats", "jabra", "sennheiser"]):
        brand = next(k for k in ["JBL","Bose","Beats","Jabra","Sennheiser"] if k.lower() in name)
        return f"{brand}|Audio"

    if any(k in name for k in ["watch", "band", "fitness", "garmin", "fitbit", "polar"]):
        return "Generic|Wearable"
    if any(k in name for k in ["keyboard", "mouse", "trackpad"]): return "Generic|KB/Mouse"

    if any(k in name for k in ["tv", "smart tv", "android tv"]): return "Generic|SmartTV"
    if any(k in name for k in ["nest", "chromecast"])           : return "Google|Home"
    if any(k in name for k in ["echo", "alexa", "kindle"])      : return "Amazon|Device"
    if any(k in name for k in ["mi home", "yeelight", "aqara"]) : return "Xiaomi|Home"

    if any(k in name for k in ["car", "auto", "bmw", "tesla", "ford"]): return "Vehicle|BT"

    return "Unknown|Device"

def remember_device(device, advertisement_data):
    rssi = getattr(advertisement_data, "rssi", None)
    if rssi is None or rssi < -100:
        return
    address = getattr(device, "address", None)
    if not address:
        return
    with devices_lock:
        devices[address] = {
            "name"   : device_label(device),
            "rssi"   : int(rssi),
            "mac"    : address,
            "type"   : get_device_type(device, advertisement_data),
            "seen_at": time.monotonic(),
        }

async def scan_forever():
    scanner = BleakScanner(detection_callback=remember_device)
    await scanner.start()
    try:
        while True:
            await asyncio.sleep(1)
    finally:
        await scanner.stop()

def ble_scan_worker():
    global scanner_error
    if BleakScanner is None:
        scanner_error = "Bleak package not found. Please run: pip install bleak"
        return
    try:
        asyncio.run(scan_forever())
    except Exception as exc:
        scanner_error = f"BLE scan failed to start: {exc}"

def lerp_color(t, dark="#050805", bright="#7cff8b"):
    def parse(h):
        h = h.lstrip("#")
        return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    r0, g0, b0 = parse(dark)
    r1, g1, b1 = parse(bright)
    r = int(r0 + (r1 - r0) * t)
    g = int(g0 + (g1 - g0) * t)
    b = int(b0 + (b1 - b0) * t)
    return f"#{r:02x}{g:02x}{b:02x}"

class Radar:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Sonar BLE Radar")
        self.root.configure(bg=COL_BG)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.minsize(480, 480)

        self.root.rowconfigure(0, weight=1)
        self.root.columnconfigure(0, weight=1)

        self.canvas = tk.Canvas(self.root, bg=COL_BG, highlightthickness=0)
        self.canvas.grid(row=0, column=0, sticky="nsew")

        self.status = tk.StringVar(value="[SYSTEM] Awaiting boot sequence...")
        tk.Label(
            self.root,
            textvariable=self.status,
            bg=COL_BG,
            fg=COL_LABEL,
            font=("Consolas", 10),
            padx=10,
            pady=6,
        ).grid(row=1, column=0, sticky="ew")

        self._fullscreen = False
        self.root.bind("<F11>", self.toggle_fullscreen)
        self.root.bind("<Escape>", self.exit_fullscreen)
        self.canvas.bind("<Button-1>", self.on_canvas_click)
        self.canvas.bind("<Motion>", self.on_mouse_move)

        self._power_hover = False

        self.angle = 0
        self.last_sweep_hit = {}
        self.current_device_positions = []
        
        self.is_booting = True
        self.boot_frame = 0

        self.root.after(40, self.update)

    def toggle_fullscreen(self, event=None):
        self._fullscreen = not self._fullscreen
        self.root.attributes("-fullscreen", self._fullscreen)

    def exit_fullscreen(self, event=None):
        self._fullscreen = False
        self.root.attributes("-fullscreen", False)

    def on_canvas_click(self, event):
        w = self.canvas.winfo_width()
        bx, by, br = self._power_btn_pos(w)
        if math.hypot(event.x - bx, event.y - by) <= br + 4:
            self.close()
            return

        if self.is_booting: return
        for x, y, data in self.current_device_positions:
            if math.hypot(event.x - x, event.y - y) < 15:
                info = f"Name: {data['name']}\nMAC: {data['mac']}\nType: {data['type']}\nRSSI: {data['rssi']} dBm"
                self.root.clipboard_clear()
                self.root.clipboard_append(info)
                old_status = self.status.get()
                self.status.set(f"COPIED: {data['name']} [{data['type']}]")
                self.root.after(2000, lambda: self.status.set(old_status))
                break

    def _power_btn_pos(self, w):
        return w - 30, 30, 14

    def on_mouse_move(self, event):
        w = self.canvas.winfo_width()
        bx, by, br = self._power_btn_pos(w)
        hover = math.hypot(event.x - bx, event.y - by) <= br + 4
        if hover != self._power_hover:
            self._power_hover = hover
            self.canvas.config(cursor="hand2" if hover else "")

    def close(self):
        stop_sound()
        self.root.destroy()

    def dims(self):
        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        if w < 2 or h < 2: w, h = 640, 640
        size  = min(w, h)
        return w, h, w // 2, h // 2, size // 2 - 20

    def rssi_to_radius(self, rssi, max_r):
        clamped  = max(-95, min(-35, rssi))
        strength = (clamped + 95) / 60
        return 35 + (1 - strength) * (max_r - 35)

    def angle_for_address(self, address):
        return hash(address) % 360

    def sweep_hits(self, target_angle):
        diff = abs((self.angle - target_angle + 180) % 360 - 180)
        return diff < 7

    def cleanup_devices(self):
        now = time.monotonic()
        with devices_lock:
            expired = [addr for addr, data in devices.items() if now - data["seen_at"] > DEVICE_TTL_SECONDS]
            for addr in expired:
                devices.pop(addr, None)
                self.last_sweep_hit.pop(addr, None)

    def snapshot_devices(self):
        with devices_lock:
            return dict(devices)

    def draw_boot_sequence(self, w, h, cx, cy):
        self.canvas.delete("all")
        self.boot_frame += 1
        
        term_text = []
        if self.boot_frame > 5: term_text.append("> WAKING UP TACTICAL NEURAL NET...")
        if self.boot_frame > 15: term_text.append("> INITIATING BLE SENSOR ARRAY...")
        if self.boot_frame > 25: term_text.append("> OVERRIDING SECURITY PROTOCOLS... [OK]")
        if self.boot_frame > 35: term_text.append("> DECRYPTING MAC ADDRESSES...")
        if self.boot_frame > 45: term_text.append("> ENGAGING RADAR SWEEP...")

        if 55 < self.boot_frame < 65:
            self.canvas.create_rectangle(0, 0, w, h, fill=COL_DIM_RING, outline="")
            self.canvas.create_text(cx, cy, text="[ SYSTEM ONLINE ]", fill=COL_BG, font=("Consolas", 32, "bold"))
            self.status.set("SYSTEM UPLINK ESTABLISHED.")
        elif self.boot_frame >= 65:
            self.is_booting = False
            start_sound() 
        else:
            ty = cy - 80
            for line in term_text:
                self.canvas.create_text(cx - 180, ty, text=line, fill=COL_TEXT, anchor="w", font=("Consolas", 10, "bold"))
                ty += 20
                
            arc_r = 30
            self.canvas.create_arc(cx-arc_r, cy+40, cx+arc_r, cy+100, start=self.boot_frame*18%360, extent=70, outline=COL_SWEEP, width=2, style=tk.ARC)
            self.canvas.create_arc(cx-arc_r, cy+40, cx+arc_r, cy+100, start=(self.boot_frame*18+180)%360, extent=70, outline=COL_SWEEP, width=2, style=tk.ARC)
            
            hex_noise = f"0x{hash(self.boot_frame) % 0xFFFFFF:06X}"
            self.canvas.create_text(cx, cy + 130, text=f"MEM_ALLOC: {hex_noise}", fill=COL_GRID_DIM, font=("Consolas", 9))
            self.status.set(f"BOOT SEQUENCE PROGRESS: {min(100, int((self.boot_frame/55)*100))}%")

    def draw_grid(self, cx, cy, max_r):
        for frac, label in RINGS:
            r = int(max_r * frac)
            self.canvas.create_oval(cx - r, cy - r, cx + r, cy + r, outline=COL_GRID)
            self.canvas.create_text(cx + 4, cy - r + 10, text=label, fill=COL_DIM_RING, font=("Consolas", 8), anchor="w")

        self.canvas.create_line(cx, cy - max_r - 10, cx, cy + max_r + 10, fill=COL_GRID)
        self.canvas.create_line(cx - max_r - 10, cy, cx + max_r + 10, cy, fill=COL_GRID)

        for deg in range(0, 360, 30):
            rad = math.radians(deg)
            x1, y1 = cx + math.cos(rad) * (max_r * 0.90), cy + math.sin(rad) * (max_r * 0.90)
            x2, y2 = cx + math.cos(rad) * max_r, cy + math.sin(rad) * max_r
            self.canvas.create_line(x1, y1, x2, y2, fill=COL_GRID_DIM)

    def draw_sweep(self, cx, cy, max_r):
        for i in range(TRAIL_STEPS):
            t = i / TRAIL_STEPS
            back_angle = (self.angle - TRAIL_SPREAD * (1 - t)) % 360
            rad = math.radians(back_angle)
            x, y = cx + math.cos(rad) * max_r, cy + math.sin(rad) * max_r
            self.canvas.create_line(cx, cy, x, y, fill=lerp_color(t * 0.55), width=1)
        
        rad = math.radians(self.angle)
        x, y = cx + math.cos(rad) * max_r, cy + math.sin(rad) * max_r
        self.canvas.create_line(cx, cy, x, y, fill=COL_SWEEP, width=2)
        self.angle = (self.angle + 3) % 360

    def draw_devices(self, snapshot, cx, cy, max_r):
        now = time.monotonic()
        shown = 0
        self.current_device_positions = []

        for address, data in snapshot.items():
            angle = self.angle_for_address(address)
            if self.sweep_hits(angle):
                self.last_sweep_hit[address] = now

            hit_age = now - self.last_sweep_hit.get(address, 0)
            if hit_age > 2.8: continue

            shown += 1
            radius = self.rssi_to_radius(data["rssi"], max_r)
            rad = math.radians(angle)
            x, y = cx + math.cos(rad) * radius, cy + math.sin(rad) * radius
            
            self.current_device_positions.append((x, y, data))

            dot_color = COL_HIT if hit_age < 0.8 else COL_FADE
            if hit_age < 0.8:
                p_r = 9 + int((0.8 - hit_age) / 0.8 * 8)
                self.canvas.create_oval(x-p_r, y-p_r, x+p_r, y+p_r, outline=COL_SWEEP)

            self.canvas.create_oval(x-5, y-5, x+5, y+5, fill=dot_color, outline="white")

            # Adjust anchor based on quadrant to avoid clipping
            tx     = x + 12 if x >= cx else x - 12
            ty     = y + 4  if y >= cy else y - 4
            anchor = "w"    if x >= cx else "e"

            self.canvas.create_text(
                tx, ty,
                text=f"{data['name']}\n{data['mac']}\n{data['type']} | {data['rssi']} dBm",
                fill=COL_TEXT, anchor=anchor, font=("Consolas", 8),
            )
        return shown

    def draw_info_panel(self, total):
        global peak_devices
        peak_devices = max(peak_devices, total)
        elapsed = int(time.monotonic() - scan_start_time)
        m, s = divmod(elapsed, 60); h, m = divmod(m, 60)
        lines = [f"TIME     {datetime.now().strftime('%H:%M:%S')}", 
                 f"ELAPSED  {h:02d}:{m:02d}:{s:02d}", 
                 f"PEAK     {peak_devices} device(s)", "",
                 "F11 Fullscreen | ESC Exit", "CLICK DOT TO COPY INFO"]
        x, y = 16, 16
        for line in lines:
            self.canvas.create_text(x, y, text=line, fill=COL_DIM_RING, anchor="nw", font=("Consolas", 9))
            y += 15

    def draw_device_table(self, snapshot, w, h):
        if not snapshot: return
        sorted_devs = sorted(snapshot.values(), key=lambda d: d["rssi"], reverse=True)
        x, line_h = 16, 14
        y = h - 16 - (len(sorted_devs) + 2) * line_h
        
        header = f"{'NAME':<13} {'MAC':<17} {'TYPE':<10} {'RSSI':>6}"
        self.canvas.create_text(x, y, text=header, fill=COL_DIM_RING, anchor="nw", font=("Consolas", 8))
        y += 13
        self.canvas.create_text(x, y, text="-"*49, fill=COL_GRID_DIM, anchor="nw", font=("Consolas", 8))
        y += 13
        
        for data in sorted_devs:
            name_trunc = data["name"][:13]
            type_trunc = data["type"][:9]
            row = f"{name_trunc:<13} {data['mac']:<17} {type_trunc:<10} {data['rssi']:>2} dBm"
            self.canvas.create_text(x, y, text=row, fill=COL_TEXT, anchor="nw", font=("Consolas", 8))
            y += line_h

    def draw_shutdown_button(self, w):
        bx, by, br = self._power_btn_pos(w)
        hover = self._power_hover

        ring_color    = "#ff4444" if hover else "#1a0a0a"
        outline_color = "#ff4444" if hover else "#7a2a2a"
        self.canvas.create_oval(
            bx - br, by - br, bx + br, by + br,
            fill=ring_color, outline=outline_color, width=1,
        )

        arc_col = "#ffffff" if hover else "#cc4444"
        arc_r   = br - 4

        self.canvas.create_arc(
            bx - arc_r, by - arc_r, bx + arc_r, by + arc_r,
            start=120, extent=300,
            outline=arc_col, width=2, style=tk.ARC,
        )

        self.canvas.create_line(
            bx, by + 2,
            bx, by - arc_r,
            fill=arc_col, width=2,
        )

    def draw_coordinates(self, cx, cy, w, h):
        self.canvas.create_text(w - 16, h - 16, text=f"RADAR CENTER: X={cx}, Y={cy}",
                                fill=COL_DIM_RING, anchor="se", font=("Consolas", 10, "bold"))

    def update(self):
        w, h, cx, cy, max_r = self.dims()

        if self.is_booting:
            self.draw_boot_sequence(w, h, cx, cy)
            self.draw_shutdown_button(w)
            self.root.after(40, self.update)
            return

        self.cleanup_devices()
        snapshot = self.snapshot_devices()
        
        self.canvas.delete("all")
        self.draw_grid(cx, cy, max_r)
        visible = self.draw_devices(snapshot, cx, cy, max_r)
        self.draw_sweep(cx, cy, max_r)
        self.draw_info_panel(len(snapshot))
        self.draw_device_table(snapshot, w, h)
        self.draw_coordinates(cx, cy, w, h)
        self.draw_shutdown_button(w)
        
        if not scanner_error:
            self.status.set(f"Tracking {len(snapshot)} BLE device(s), {visible} visible. Click dots to copy.")
        else:
            self.status.set(scanner_error)

        self.root.after(40, self.update)

    def run(self):
        if BleakScanner is None:
            messagebox.showerror("Error", "Please install bleak: pip install bleak")
        self.root.mainloop()

if __name__ == "__main__":
    threading.Thread(target=ble_scan_worker, daemon=True).start()
    Radar().run()